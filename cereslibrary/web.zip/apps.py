from django.apps import AppConfig


class CereslibraryConfig(AppConfig):
    name = 'cereslibrary'
